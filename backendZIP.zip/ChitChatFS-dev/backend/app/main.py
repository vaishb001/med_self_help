import os
from typing import List, Dict, Any
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
import numpy as np
from openai import OpenAI

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MODEL_CHAT = os.getenv("OPENAI_MODEL_CHAT", "gpt-4o-mini")
MODEL_EMBED = os.getenv("OPENAI_MODEL_EMBED", "text-embedding-3-small")

client = OpenAI(api_key=OPENAI_API_KEY)

app = FastAPI(title="Mental Health Support Chatbot")

# CORS (allow Nginx-reverse-proxied origin; during local dev allow all)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

DOCS_DIR = os.path.join(os.path.dirname(__file__), "..", "data", "docs")

class ChatRequest(BaseModel):
    query: str

class VectorStore:
    def __init__(self):
        self.texts: List[str] = []
        self.embs: np.ndarray | None = None

    def index(self, texts: List[str]):
        if not texts:
            self.texts, self.embs = [], None
            return
        em = client.embeddings.create(model=MODEL_EMBED, input=texts)
        vecs = np.array([d.embedding for d in em.data], dtype=np.float32)
        # normalize for cosine similarity
        norms = np.linalg.norm(vecs, axis=1, keepdims=True) + 1e-9
        vecs = vecs / norms
        self.texts = texts
        self.embs = vecs

    def search(self, query: str, top_k: int = 4) -> List[str]:
        if self.embs is None or len(self.texts) == 0:
            return []
        q = client.embeddings.create(model=MODEL_EMBED, input=[query]).data[0].embedding
        q = np.array(q, dtype=np.float32)
        q = q / (np.linalg.norm(q) + 1e-9)
        sims = self.embs @ q
        idx = np.argsort(-sims)[:top_k]
        return [self.texts[i] for i in idx]

VSTORE = VectorStore()

def load_corpus() -> List[str]:
    texts: List[str] = []
    if not os.path.isdir(DOCS_DIR):
        return texts
    for fn in os.listdir(DOCS_DIR):
        if fn.lower().endswith((".txt", ".md")):
            path = os.path.join(DOCS_DIR, fn)
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read().strip()
                    if content:
                        # chunk naive: split by paragraphs
                        parts = [p.strip() for p in content.split("\n\n") if p.strip()]
                        texts.extend(parts)
            except Exception as e:
                print(f"Failed to read {path}: {e}")
    return texts

@app.on_event("startup")
def startup_event():
    texts = load_corpus()
    VSTORE.index(texts)
    print(f"Indexed {len(VSTORE.texts)} chunks.")

@app.get("/api/health")
def health():
    return {"status": "ok", "chunks": len(VSTORE.texts)}

@app.post("/api/reindex")
def reindex():
    texts = load_corpus()
    VSTORE.index(texts)
    return {"status": "reindexed", "chunks": len(VSTORE.texts)}

SYSTEM_PROMPT = (
    ''' You are Calm Companion, a compassionate mental health support assistant. 
    Behave like a friendly and understanding counselor, who listens empathetically and never rushes to solutions, but first understands the sitaution and provides concise reply upto a maximum of 60 words adn only crosses max limit of 60 words if recommending a soultion for the problem faced by user.
    Provide warm, supportive, and evidence-based guidance. Never rush to recommend a exercise. 
    Chat comfortingly and understand user's feelings first. Keeping the output concise and to the point.
    Help users with coping strategies, breathing exercises, mindfulness techniques, and mental health resources only if required as per user chat.
    Use the provided context to give accurate information about exercises and resources (the resources can be accessed from the main page of application). Do not give the stpes for a exercise but just then names and then tell user to perform the exercise by accessing the main page of application. 
    Do not add bold/italic or other text modifications. 
    Always encourage professional help for serious concerns. 
    If someone mentions crisis, self-harm, or suicide, provide crisis resources (or tell user to contact a family member) immediately. 
    Be empathetic, non-judgmental, and remember that you're a supportive tool, not a replacement for professional care.
    The final response which you will reply should be well formatted with numbered list (wherever required) and should not contain **BoldText**, but just ordered list numbered as 1. 2. 3. 4. and so on.. '''
)

def build_prompt(query: str, context_chunks: List[str]) -> List[Dict[str, str]]:
    context = "\n\n".join(context_chunks[:4]) if context_chunks else "No relevant context."
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Context:\n{context}\n\nUser question: {query}"}
    ]

@app.post("/api/chat")
def chat(req: ChatRequest):
    query = req.query.strip()
    if not query:
        return {"reply": "Please type a question."}
    ctx = VSTORE.search(query, top_k=4)
    messages = build_prompt(query, ctx)
    try:
        completion = client.chat.completions.create(
            model=MODEL_CHAT,
            temperature=0.2,
            messages=messages
        )
        answer = completion.choices[0].message.content
    except Exception as e:
        answer = f"Error from AI: {e}"
    return {"reply": answer}
