# Coping Strategies and Self-Care Tips

## Daily Self-Care Practices

### Physical Self-Care
- Get regular exercise, even a short walk
- Maintain a consistent sleep schedule
- Eat balanced, nourishing meals
- Stay hydrated throughout the day
- Limit caffeine and alcohol

### Emotional Self-Care
- Practice self-compassion
- Journal your thoughts and feelings
- Allow yourself to feel emotions without judgment
- Set healthy boundaries with others
- Engage in activities you enjoy

### Mental Self-Care
- Challenge negative thought patterns
- Practice mindfulness or meditation
- Limit social media and news consumption
- Learn something new
- Take regular breaks from work

### Social Self-Care
- Connect with supportive friends and family
- Join support groups or communities
- Seek professional help when needed
- Practice active listening in relationships
- Set aside time for meaningful connections

## When to Seek Professional Help

Consider reaching out to a mental health professional if you experience:
- Persistent feelings of sadness or hopelessness lasting more than 2 weeks
- Difficulty performing daily tasks or responsibilities
- Changes in sleep or appetite patterns
- Thoughts of self-harm or suicide
- Substance use as a coping mechanism
- Overwhelming anxiety or panic attacks
- Inability to enjoy activities you once loved

## Emergency Resources

- If you're in immediate danger, call 911 (US) or your local emergency number
- National Suicide Prevention Lifeline: 988
- Crisis Text Line: Text HOME to 741741
- SAMHSA National Helpline: 1-800-662-4357

## Remember

Recovery is a journey, not a destination. Small steps forward are still progress. Be patient and kind with yourself.
