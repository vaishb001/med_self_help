# Mental Health Resources & Information

## Available Exercises

### Box Breathing
A simple breathing technique to help calm anxiety and reduce stress. Breathe in for 4 counts, hold for 4, breathe out for 4, hold for 4. Repeat for several cycles.

### Grounding Exercise (5-4-3-2-1)
A technique to help you stay present when feeling overwhelmed:
- 5 things you can see
- 4 things you can touch
- 3 things you can hear
- 2 things you can smell
- 1 thing you can taste

### Progressive Muscle Relaxation
A technique involving tensing and then relaxing different muscle groups to release physical tension and promote relaxation.

### Body Scan
A mindfulness practice where you mentally scan your body from head to toe, noticing sensations without judgment. Helps with sleep and relaxation.

### Thought Labeler
A cognitive technique to help identify and label thoughts and feelings, creating distance from overwhelming emotions.

## Crisis Support

If you're experiencing a mental health crisis or having thoughts of self-harm, please reach out immediately:
- National Suicide Prevention Lifeline: 988 (US)
- Crisis Text Line: Text HOME to 741741
- International Association for Suicide Prevention: https://www.iasp.info/resources/Crisis_Centres/

## Common Mental Health Concerns

### Anxiety
Characterized by excessive worry, restlessness, and physical symptoms like rapid heartbeat. Breathing exercises and grounding techniques can help manage acute symptoms.

### Depression
Persistent feelings of sadness, loss of interest, and low energy. Professional support is important. Self-help exercises can complement treatment.

### Stress
The body's response to challenging situations. Regular relaxation practices and setting boundaries can help manage stress levels.

### Sleep Issues
Difficulty falling or staying asleep. Body scan exercises and establishing a regular sleep routine can improve sleep quality.
